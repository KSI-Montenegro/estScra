# estitor_518250

Source: https://estitor.com/me/nekretnine/namjena-izdavanje/tip-stan/grad-podgorica/id-518250

- Deal: rent
- Property type: apartment
- Price amount: 650
- Currency: EUR
- City: Podgorica

## Original listing description

[No source description available.]

## Missing core data

title, description_original, area, images

This is a source-based draft. Missing facts have not been invented. Field provenance and conflicts are recorded in details.json.
